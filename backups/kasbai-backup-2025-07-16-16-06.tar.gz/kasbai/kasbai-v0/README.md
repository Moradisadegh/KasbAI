# KasbAI - نسخه 0

این نسخه اولیه پروژه KasbAI است که شامل:
- راه‌اندازی اولیه FastAPI
- اتصال به GapGPT API
- تست موفق با UI ساده HTML


