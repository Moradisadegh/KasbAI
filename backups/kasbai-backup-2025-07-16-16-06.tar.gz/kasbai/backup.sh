#!/bin/bash

# 🗓 تاریخ و زمان
TIMESTAMP=$(date +"%Y-%m-%d-%H-%M")
BACKUP_DIR="/root/kasbai/backups"
BACKUP_FILE="$BACKUP_DIR/kasbai-backup-$TIMESTAMP.tar.gz"

# ✅ اطمینان از وجود پوشه backups
mkdir -p "$BACKUP_DIR"

# 🗜 فشرده‌سازی کل محتویات kasbai (به جز خود پوشه backups)
tar --exclude="$BACKUP_DIR" -czvf "$BACKUP_FILE" -C /root kasbai

# 🚀 ارسال بکاپ به گیت
cd /root/kasbai
git add backups/
git commit -m "📦 Full project backup on $TIMESTAMP"
git push origin main

echo "✅ Full backup created and pushed to GitHub at $TIMESTAMP"
